using Android;
using Android.App;
using Android.Content.PM;
using Android.Content;
using Android.Bluetooth;
using Android.OS;
using Android.Widget;
using AndroidX.Core.App;
using AndroidX.Core.Content;
using Avalonia;
using Avalonia.Android;
using GalaxyBudsClient.Android.Impl;
using GalaxyBudsClient.Platform;
using ReactiveUI.Avalonia;
using AlertDialog = AndroidX.AppCompat.App.AlertDialog;

#if DEBUG && !NotDebuggable
[assembly: Application(Debuggable=true)]
#else
[assembly: Application(Debuggable=false)]
#endif

namespace GalaxyBudsClient.Android;

[Activity(
    Label = "Buds Classic",
    Theme = "@style/MyTheme.NoActionBar",
    Icon = "@mipmap/ic_launcher",
    MainLauncher = true,
    ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize | ConfigChanges.UiMode)]
public class MainActivity : AvaloniaMainActivity<App>
{
    private const int RequestBluetoothPermission = 1;
    private BroadcastReceiver? _connectionReceiver;

    // First prototype: shows a native popup while the app is open.
    // A background connection popup will require a separate Android service.
    private sealed class ConnectionReceiver(MainActivity activity) : BroadcastReceiver
    {
        public override void OnReceive(Context? context, Intent? intent)
        {
            if (intent?.Action != BluetoothDevice.ActionAclConnected) return;
            var device = intent.GetParcelableExtra(BluetoothDevice.ExtraDevice) as BluetoothDevice;
            string name;
            try { name = device?.Name ?? "Bluetooth device"; }
            catch (Java.Lang.SecurityException) { return; }
            if (!name.Contains("Buds", StringComparison.OrdinalIgnoreCase)) return;
            activity.RunOnUiThread(() => activity.ShowConnectionPopup(name));
        }
    }

    private void ShowConnectionPopup(string deviceName)
    {
        if (IsFinishing || IsDestroyed) return;
        new AlertDialog.Builder(this)
            .SetTitle("Buds Classic  •  Connected")
            .SetMessage($"{deviceName}\n\nOpen Buds Classic to view battery, ANC, EQ and Game Mode.")
            .SetPositiveButton("Open", (_, _) => { })
            .SetNegativeButton("Dismiss", (_, _) => { })
            .Show();
    }

    protected override void OnStart()
    {
        base.OnStart();
        _connectionReceiver = new ConnectionReceiver(this);
        var filter = new IntentFilter(BluetoothDevice.ActionAclConnected);
        if (Build.VERSION.SdkInt >= BuildVersionCodes.Tiramisu)
            RegisterReceiver(_connectionReceiver, filter, ReceiverFlags.Exported);
        else
            RegisterReceiver(_connectionReceiver, filter);
    }

    protected override void OnStop()
    {
        if (_connectionReceiver != null)
        {
            UnregisterReceiver(_connectionReceiver);
            _connectionReceiver = null;
        }
        base.OnStop();
    }
    
    protected override AppBuilder CustomizeAppBuilder(AppBuilder builder)
    {
        Program.Startup(false, new LogcatSink("GbClient"));
        PlatformImpl.InjectExternalBackend(new AndroidPlatformImplCreator(this));
        
        return base.CustomizeAppBuilder(builder)
            .WithInterFont()
            .LogToTrace()
            .UseReactiveUI();
    }
    
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        
        if (Build.VERSION.SdkInt >= BuildVersionCodes.S) {
#pragma warning disable CA1416
            ActivityCompat.RequestPermissions(this, [Manifest.Permission.BluetoothConnect], RequestBluetoothPermission);
#pragma warning restore CA1416
        }
        else if (Build.VERSION.SdkInt >= BuildVersionCodes.M && ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessFineLocation) != Permission.Granted)
        {
            Toast.MakeText(this, "Location permission required to scan for Bluetooth devices nearby.", ToastLength.Long);
            ActivityCompat.RequestPermissions(this, [Manifest.Permission.AccessFineLocation], RequestBluetoothPermission);
        }
    }
    
    public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
    {
        if (requestCode == RequestBluetoothPermission) 
        {
            // Check if the only required permission has been granted
            if (grantResults is not [Permission.Granted]) {    
                new AlertDialog.Builder(this)?
                    .SetTitle("Required permissions not granted")?
                    .SetMessage("Cannot start without the required Bluetooth permissions. Please visit the system settings to grant the missing permissions manually.")?
                    .SetNegativeButton("Close app", (_, _) => Finish())
                    .Show();
            }
        } 
        else 
        {
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
