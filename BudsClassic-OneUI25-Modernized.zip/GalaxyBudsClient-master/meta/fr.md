# fr (France)

This file is auto-generated and automatically updated. Do not modify this file manually.

<table>
<tr><th>Progress</th><th>Count</th></tr>
<tr><td>50%</td><td>294 missing string(s)</td></tr>
</table>

### Missing strings

<table>
<tr><th>Key</th><th>Original string</th></tr>
<tr><td><code>both</code></td><td>Both</td></tr>
<tr><td><code>next</code></td><td>Next</td></tr>
<tr><td><code>prev</code></td><td>Previous</td></tr>
<tr><td><code>off</code></td><td>Off</td></tr>
<tr><td><code>on</code></td><td>On</td></tr>
<tr><td><code>hint</code></td><td>Hint</td></tr>
<tr><td><code>help</code></td><td>Help</td></tr>
<tr><td><code>important</code></td><td>Important</td></tr>
<tr><td><code>home</code></td><td>Home</td></tr>
<tr><td><code>read_failed</code></td><td>Failed to read file. Access denied.</td></tr>
<tr><td><code>please_wait</code></td><td>Please wait...</td></tr>
<tr><td><code>value_left_right_inline</code></td><td>Left: {0}, Right: {1}</td></tr>
<tr><td><code>value_left_right_multiline</code></td><td>Left: {0}
Right: {1}</td></tr>
<tr><td><code>other_x</code></td><td>Other ({0})</td></tr>
<tr><td><code>no_data_stored</code></td><td>No data stored</td></tr>
<tr><td><code>not_available</code></td><td>Not available</td></tr>
<tr><td><code>last_updated_at_n</code></td><td>Last updated at {0}</td></tr>
<tr><td><code>file_not_found</code></td><td>File not found</td></tr>
<tr><td><code>feature_unsupported_platform</code></td><td>This feature is currently not supported on this platform.</td></tr>
<tr><td><code>adaptive</code></td><td>Adaptive</td></tr>
<tr><td><code>darkmode_blur_enabled</code></td><td>On, with blur effect</td></tr>
<tr><td><code>darkmode_mica_enabled</code></td><td>On, with mica effect</td></tr>
<tr><td><code>placement_charging</code></td><td>Charging</td></tr>
<tr><td><code>touchoption_custom_trigger_event</code></td><td>Trigger earbud action...</td></tr>
<tr><td><code>hotkey_add_short</code></td><td>New</td></tr>
<tr><td><code>hotkey_edit_long</code></td><td>Edit existing hotkey</td></tr>
<tr><td><code>event_nc_switch_one</code></td><td>Switch noise controls with one earbud</td></tr>
<tr><td><code>welcome_register</code></td><td>Set-up your earbuds</td></tr>
<tr><td><code>welcome_register_desc</code></td><td>Choose and register your pair of Galaxy Buds</td></tr>
<tr><td><code>welcome_android_hint_title</code></td><td>Important information for Android users</td></tr>
<tr><td><code>welcome_android_hint</code></td><td>This app was initially designed for use on desktop computers. Features that need this app to run in the background, such as custom touch actions and battery statistics, are currently unavailable in this version.
If the official Samsung Wearable app is active alongside this app, connection issues may occur. Please make sure to close the official app properly before using this app.</td></tr>
<tr><td><code>mainpage_header</code></td><td>Home</td></tr>
<tr><td><code>mainpage_fit_test</code></td><td>Earbud fit test</td></tr>
<tr><td><code>devsel_manual_pair_title</code></td><td>Is your device not listed?</td></tr>
<tr><td><code>devsel_manual_pair_description</code></td><td>Make sure your earbuds have already been paired. If they are still not recognized, try using the manual connection option.</td></tr>
<tr><td><code>devsel_manual_pair</code></td><td>Manual connection</td></tr>
<tr><td><code>devices_header</code></td><td>Paired devices</td></tr>
<tr><td><code>devices_new</code></td><td>New</td></tr>
<tr><td><code>devices_new_long</code></td><td>Pair new device</td></tr>
<tr><td><code>devices_select_inactive</code></td><td>Select</td></tr>
<tr><td><code>devices_select_active</code></td><td>Selected</td></tr>
<tr><td><code>devices_delete</code></td><td>Delete</td></tr>
<tr><td><code>devices_delete_long</code></td><td>Delete device</td></tr>
<tr><td><code>devices_delete_confirmation</code></td><td>Are you sure you want to remove this device?</td></tr>
<tr><td><code>devices_settings_link</code></td><td>Manage paired devices</td></tr>
<tr><td><code>devices_settings_link_desc</code></td><td>Add, remove, or select a primary device</td></tr>
<tr><td><code>touchpad_gesture_header</code></td><td>Enable touchpad gestures</td></tr>
<tr><td><code>touchpad_gesture_single</code></td><td>Single tap</td></tr>
<tr><td><code>touchpad_gesture_single_desc</code></td><td>Play or pause track</td></tr>
<tr><td><code>touchpad_gesture_double</code></td><td>Double tap</td></tr>
<tr><td><code>touchpad_gesture_double_desc</code></td><td>Play next track</td></tr>
<tr><td><code>touchpad_gesture_triple</code></td><td>Triple tap</td></tr>
<tr><td><code>touchpad_gesture_triple_desc</code></td><td>Play previous track</td></tr>
<tr><td><code>touchpad_gesture_hold</code></td><td>Touch and hold</td></tr>
<tr><td><code>touchpad_gesture_hold_desc</code></td><td>Execute custom action</td></tr>
<tr><td><code>touchpad_gesture_double_for_call</code></td><td>Double tap during call</td></tr>
<tr><td><code>touchpad_gesture_double_for_call_desc</code></td><td>Answer call or end call</td></tr>
<tr><td><code>touchpad_gesture_hold_for_call</code></td><td>Touch and hold during call</td></tr>
<tr><td><code>touchpad_gesture_hold_for_call_desc</code></td><td>Decline call</td></tr>
<tr><td><code>touchpad_default_action</code></td><td>Built-in touch action</td></tr>
<tr><td><code>touchpad_gestures</code></td><td>Advanced touch lock</td></tr>
<tr><td><code>touchpad_gestures_description</code></td><td>Disable default touch gestures</td></tr>
<tr><td><code>touchpad_noise_control_mode_l</code></td><td>Noise control switching mode (Left)</td></tr>
<tr><td><code>touchpad_noise_control_mode_r</code></td><td>Noise control switching mode (Right)</td></tr>
<tr><td><code>touchpad_noise_control_mode_desc</code></td><td>Choose modes to cycle through</td></tr>
<tr><td><code>cact_function_param</code></td><td>Function</td></tr>
<tr><td><code>cact_hotkey_param</code></td><td>Hotkey</td></tr>
<tr><td><code>cact_path_param</code></td><td>File path</td></tr>
<tr><td><code>system_hidden_at_mode</code></td><td>Hidden system settings</td></tr>
<tr><td><code>system_hidden_at_mode_desc</code></td><td>Edit hidden settings such as serial numbers and UART state</td></tr>
<tr><td><code>system_usage_reports</code></td><td>Usage & metering reports</td></tr>
<tr><td><code>system_usage_reports_desc</code></td><td>View usage reports provided by the earbuds</td></tr>
<tr><td><code>system_battery_statistics</code></td><td>Battery statistics</td></tr>
<tr><td><code>system_battery_statistics_desc</code></td><td>Collect & view battery usage statistics</td></tr>
<tr><td><code>system_no_response</code></td><td>No response from earbuds</td></tr>
<tr><td><code>system_cradle_swver</code></td><td>Case software version</td></tr>
<tr><td><code>system_cradle_serial</code></td><td>Case serial number</td></tr>
<tr><td><code>system_btaddr_template</code></td><td>Local address: {0}, Peer address: {1}</td></tr>
<tr><td><code>system_sku</code></td><td>Device SKUs</td></tr>
<tr><td><code>hidden_mode_warning</code></td><td>Proceed with caution</td></tr>
<tr><td><code>hidden_mode_warning_desc</code></td><td>Some changes made on this page cannot be restored by a factory reset. Not all models support these settings.</td></tr>
<tr><td><code>hidden_mode_target</code></td><td>Target device: {0} earbud</td></tr>
<tr><td><code>hidden_mode_target_l_desc</code></td><td>To modify your left earbud, put the right earbud into the case and close it.</td></tr>
<tr><td><code>hidden_mode_target_r_desc</code></td><td>To modify your right earbud, put the left earbud into the case and close it.</td></tr>
<tr><td><code>hidden_mode_input_wrong_length</code></td><td>The new value must be exactly {0} characters long.</td></tr>
<tr><td><code>hidden_mode_uart_on_confirm</code></td><td>UART has been successfully enabled</td></tr>
<tr><td><code>hidden_mode_uart_off_confirm</code></td><td>UART has been successfully disabled</td></tr>
<tr><td><code>hidden_mode_uart</code></td><td>Enable UART port</td></tr>
<tr><td><code>hidden_mode_uart_desc</code></td><td>Temporarily enables the physical UART port on the PCB of the current target device for debugging purposes</td></tr>
<tr><td><code>hidden_mode_power</code></td><td>Power menu</td></tr>
<tr><td><code>hidden_mode_power_desc</code></td><td>Shutdown, reboot or put the current target device to sleep</td></tr>
<tr><td><code>hidden_mode_serial_change</code></td><td>Change serial number</td></tr>
<tr><td><code>hidden_mode_serial_change_desc</code></td><td>Changes the serial number of the current target device</td></tr>
<tr><td><code>hidden_mode_did_change</code></td><td>Change DID number & color</td></tr>
<tr><td><code>hidden_mode_did_change_desc</code></td><td>Changes the device model id of the current target device</td></tr>
<tr><td><code>hidden_mode_sku_change</code></td><td>Change SKU code</td></tr>
<tr><td><code>hidden_mode_sku_change_desc</code></td><td>Changes the product code of the current target device</td></tr>
<tr><td><code>hidden_mode_bt_peer_addr_change</code></td><td>Change peer Bluetooth address</td></tr>
<tr><td><code>hidden_mode_bt_peer_change_desc</code></td><td>Changes the peer Bluetooth address of the current target device</td></tr>
<tr><td><code>hidden_mode_bt_local_addr_change</code></td><td>Change local Bluetooth address</td></tr>
<tr><td><code>hidden_mode_bt_local_change_desc</code></td><td>Changes the local Bluetooth address of the current target device</td></tr>
<tr><td><code>hidden_mode_terminal</code></td><td>Hidden command terminal</td></tr>
<tr><td><code>hidden_mode_terminal_desc</code></td><td>Send custom AT commands to the current target device</td></tr>
<tr><td><code>power_menu_hint</code></td><td>Only the current target earbud will be affected.</td></tr>
<tr><td><code>power_menu_reboot</code></td><td>Reboot</td></tr>
<tr><td><code>power_menu_shutdown</code></td><td>Shutdown</td></tr>
<tr><td><code>power_menu_sleep</code></td><td>Factory sleep mode</td></tr>
<tr><td><code>at_terminal_cmd_id</code></td><td>Command id</td></tr>
<tr><td><code>at_terminal_cmd_param</code></td><td>Command parameter (optional)</td></tr>
<tr><td><code>at_terminal_cmd_id_invalid</code></td><td>This command id is invalid. Please enter a 16-bit hexadecimal value, such as 0007 or 004C.</td></tr>
<tr><td><code>at_terminal_output</code></td><td>Output</td></tr>
<tr><td><code>at_terminal_send</code></td><td>Send</td></tr>
<tr><td><code>usage_reports_header</code></td><td>Usage reports</td></tr>
<tr><td><code>usage_reports_hint</code></td><td>These reports are collected by the earbuds themselves. The data is displayed as-is and may be inaccurate. The official Wearable app usually resets most counters periodically and then sends the collected data to Samsung unless you haven't consented to data collection in their app. Some counters, such as charging cycles, are not reset.</td></tr>
<tr><td><code>usage_reports_usage</code></td><td>Usage report</td></tr>
<tr><td><code>usage_reports_metering</code></td><td>Metering report</td></tr>
<tr><td><code>milliamp_hours_unit</code></td><td>{0}mAh</td></tr>
<tr><td><code>metering_total_batt_capacity</code></td><td>Total battery capacity</td></tr>
<tr><td><code>metering_a2dp_time</code></td><td>Music playback usage time (A2DP)</td></tr>
<tr><td><code>metering_esco_time</code></td><td>Call usage time (eSCO)</td></tr>
<tr><td><code>batt_hist_hint</code></td><td>This app can collect battery levels and basic usage data over time, allowing you to analyze battery drain. Data can only be collected while this app is active in the background and your earbuds are connected to this device.</td></tr>
<tr><td><code>batt_hist_no_data_title</code></td><td>Not enough data</td></tr>
<tr><td><code>batt_hist_no_data</code></td><td>Please come back at a later time when enough data has been collected or adjust the shown time-span.</td></tr>
<tr><td><code>batt_hist_y_axis</code></td><td>Charge (%)</td></tr>
<tr><td><code>batt_hist_last_hour</code></td><td>Last hour</td></tr>
<tr><td><code>batt_hist_last_6_hours</code></td><td>Last 6 hours</td></tr>
<tr><td><code>batt_hist_last_12_hours</code></td><td>Last 12 hours</td></tr>
<tr><td><code>batt_hist_last_24_hours</code></td><td>Last 24 hours</td></tr>
<tr><td><code>batt_hist_last_3_days</code></td><td>Last 3 days</td></tr>
<tr><td><code>batt_hist_last_7_days</code></td><td>Last 7 days</td></tr>
<tr><td><code>batt_hist_overlay_none</code></td><td>No overlay</td></tr>
<tr><td><code>batt_hist_overlay_noise_controls</code></td><td>Noise controls</td></tr>
<tr><td><code>batt_hist_overlay_wearing</code></td><td>Wear state</td></tr>
<tr><td><code>batt_hist_overlay_host_device</code></td><td>Host device</td></tr>
<tr><td><code>batt_hist_overlay_legend</code></td><td>{0} (Overlay)</td></tr>
<tr><td><code>batt_hist_tools_pan_and_zoom</code></td><td>Pan & zoom</td></tr>
<tr><td><code>batt_hist_tools_measure_time</code></td><td>Measure time</td></tr>
<tr><td><code>batt_hist_tools_measure_battery</code></td><td>Measure level</td></tr>
<tr><td><code>batt_hist_show_legend</code></td><td>Show legend</td></tr>
<tr><td><code>batt_hist_measure_difference_display</code></td><td>Difference: {0}</td></tr>
<tr><td><code>batt_hist_measure_timespan_display</code></td><td>Time span: {0}</td></tr>
<tr><td><code>batt_hist_measure_timespan_unit_long</code></td><td>d' day(s), 'hh'h:'mm':'ss</td></tr>
<tr><td><code>batt_hist_time_span_tip_title</code></td><td>Time span</td></tr>
<tr><td><code>batt_hist_control_tip_title</code></td><td>Mouse controls</td></tr>
<tr><td><code>batt_hist_control_tip</code></td><td>Drag the canvas to move around the plot.

Scroll to zoom horizontally and vertically.

Hover over the X or Y axis and scroll to zoom only horizontally or vertically. Scrolling over the X-axis (time) would stretch or squash it, for example.</td></tr>
<tr><td><code>batt_hist_overlay_tip_title</code></td><td>Overlays</td></tr>
<tr><td><code>batt_hist_overlay_tip</code></td><td>You can use overlays to add additional context to the plot.

Noise controls: Shows which noise controls were enabled or disabled.

Wear state: Shows if the earbuds were worn or not.

Host device: Shows which earbud is hosting the Bluetooth connection to the computer

The overlay data may be hard to understand when viewing large time ranges. Hover over the X-axis and scroll up to zoom into a specific time range you want to inspect for a better overview.</td></tr>
<tr><td><code>batt_hist_tools_tip_title</code></td><td>Tools</td></tr>
<tr><td><code>batt_hist_tools_tip</code></td><td>Pan & zoom: Default mode. Navigate around the plot by panning and zooming.

Measure time: Select a horizontal span to measure the elapsed time between the start and end of the selection.

Measure level: Select a vertical span to measure the battery level difference between the start and end of the selection.</td></tr>
<tr><td><code>settings_save_fail_no_access</code></td><td>Failed to save settings. Access to the configuration file has been denied by the operating system. Please check the file permissions for {0}.</td></tr>
<tr><td><code>settings_appearance</code></td><td>Appearance</td></tr>
<tr><td><code>settings_blurstrength</code></td><td>Window blur strength</td></tr>
<tr><td><code>settings_blurstrength_description</code></td><td>Only compatible with dark mode. Not supported on all systems</td></tr>
<tr><td><code>settings_accent</code></td><td>Accent color</td></tr>
<tr><td><code>settings_accent_description</code></td><td>Choose a custom accent color</td></tr>
<tr><td><code>settings_localization_description</code></td><td>Change the app language</td></tr>
<tr><td><code>settings_realistic_earbud_icons</code></td><td>Use realistic earbud images</td></tr>
<tr><td><code>settings_realistic_earbud_icons_description</code></td><td>Display realistic & color-aware images of your earbuds, if they support it</td></tr>
<tr><td><code>settings_color_override</code></td><td>Earbud color override</td></tr>
<tr><td><code>settings_color_override_description</code></td><td>Change the displayed color of your earbuds in the app</td></tr>
<tr><td><code>settings_nav_sidebar</code></td><td>Navigation sidebar</td></tr>
<tr><td><code>settings_nav_sidebar_description</code></td><td>Show or collapse the navigation buttons on the left hand side</td></tr>
<tr><td><code>settings_tray_settings</code></td><td>Tray icon & startup</td></tr>
<tr><td><code>settings_dyn_tray_mode</code></td><td>Dynamic tray icon</td></tr>
<tr><td><code>settings_dyn_tray_mode_description</code></td><td>Display the battery status in the tray icon</td></tr>
<tr><td><code>settings_dyn_tray_mode_off</code></td><td>Off</td></tr>
<tr><td><code>settings_dyn_tray_mode_battery_min</code></td><td>Show lowest battery level</td></tr>
<tr><td><code>settings_dyn_tray_mode_battery_avg</code></td><td>Show average battery level</td></tr>
<tr><td><code>settings_devmode_description</code></td><td>Bluetooth traffic inspector and other developer tools</td></tr>
<tr><td><code>settings_crowdsourcing</code></td><td>Crowdsourcing</td></tr>
<tr><td><code>settings_cpopup_position_description</code></td><td>Select the position of the connection popup</td></tr>
<tr><td><code>settings_crowd_header</code></td><td>Crowdsourcing</td></tr>
<tr><td><code>settings_crowd_allow</code></td><td>Allow crowdsourcing contribution</td></tr>
<tr><td><code>settings_crowd_allow_description</code></td><td>Collect information about Samsung's proprietary Bluetooth protocol structure and data on demand. This allows me to keep all available Galaxy Buds models supported much more easily without owning them.</td></tr>
<tr><td><code>settings_crowd_crashreport</code></td><td>Allow app crash reports</td></tr>
<tr><td><code>settings_crowd_crashreport_description</code></td><td>Send application crash reports automatically in case of crashes or fatal errors using Sentry. This helps me to respond more quickly to problematic and disruptive application bugs.</td></tr>
<tr><td><code>settings_multipoint_header</code></td><td>Multipoint</td></tr>
<tr><td><code>settings_multipoint_auto</code></td><td>Unlock multipoint without a Samsung account</td></tr>
<tr><td><code>settings_multipoint_auto_description</code></td><td>Your earbuds normally drop your phone as soon as a non-Samsung device connects, unless the Galaxy Wearable app is signed in. Enabling this writes the missing version marker to your earbuds every time they connect, which lets both devices stay connected. The earbuds keep the marker only until they power down, so putting them back in the case clears it.</td></tr>
<tr><td><code>settings_multipoint_apply</code></td><td>Apply now</td></tr>
<tr><td><code>settings_multipoint_apply_description</code></td><td>Write the marker again. Your earbuds will briefly disconnect and reconnect.</td></tr>
<tr><td><code>settings_multipoint_applied</code></td><td>Multipoint unlocked. Connect your phone to test it.</td></tr>
<tr><td><code>settings_multipoint_failed</code></td><td>Could not unlock multipoint. Make sure your earbuds are connected and try again.</td></tr>
<tr><td><code>factory_confirmation</code></td><td>Are you sure you want to reset your earbuds to factory settings?
This will remove all data and settings from your earbuds.

Make sure both earbuds are turned on before continuing.</td></tr>
<tr><td><code>fmg_smart_things_find_manage</code></td><td>Manage SmartThings Find data</td></tr>
<tr><td><code>fmg_smart_things_find_manage_desc</code></td><td>View and manage your SmartThings Find data stored on your earbuds</td></tr>
<tr><td><code>fmg_smart_things_find_open</code></td><td>Open SmartThings Find website</td></tr>
<tr><td><code>fmg_smart_things_find_open_desc</code></td><td>Track your earbuds online. Requires a Samsung account and the official SmartThings Find app to be set-up.</td></tr>
<tr><td><code>smart_things_find</code></td><td>SmartThings</td></tr>
<tr><td><code>smart_things_find_clear</code></td><td>Delete SmartThings Find configuration</td></tr>
<tr><td><code>smart_things_find_clear_desc</code></td><td>Remove Samsung Account related data from your earbuds</td></tr>
<tr><td><code>smart_things_find_iv</code></td><td>Initialization vector (IV)</td></tr>
<tr><td><code>smart_things_find_secret_key</code></td><td>Secret key</td></tr>
<tr><td><code>smart_things_find_region</code></td><td>Region</td></tr>
<tr><td><code>smart_things_find_fmm_token</code></td><td>SmartThings Find token</td></tr>
<tr><td><code>smart_things_find_no_link</code></td><td>Your earbuds are not linked to the Samsung SmartThings Find network.</td></tr>
<tr><td><code>smart_things_find_write_fail</code></td><td>The earbuds rejected the new SmartThings Find configuration data.</td></tr>
<tr><td><code>smart_things_find_write_ok</code></td><td>Configuration overwritten</td></tr>
<tr><td><code>smart_things_find_write_ok_desc</code></td><td>The SmartThings Find configuration data has been removed.</td></tr>
<tr><td><code>gft_warning</code></td><td>Please wear both earbuds.</td></tr>
<tr><td><code>gft_desc</code></td><td>Check whether your earbuds are seated correctly</td></tr>
<tr><td><code>gft_bad</code></td><td>Bad fit</td></tr>
<tr><td><code>gft_good</code></td><td>Good fit</td></tr>
<tr><td><code>gft_fail</code></td><td>Test failed</td></tr>
<tr><td><code>eq_enable_description</code></td><td>Apply EQ audio filters</td></tr>
<tr><td><code>nc_as_anc_description</code></td><td>Reduce background noises</td></tr>
<tr><td><code>nc_one_earbud</code></td><td>Noise controls with one earbud</td></tr>
<tr><td><code>nc_one_earbud_description</code></td><td>Noise controls normally require two earbuds to prevent discomfort, enable this to allow it with only one earbud</td></tr>
<tr><td><code>nc_ambient</code></td><td>Customize ambient sound</td></tr>
<tr><td><code>nc_ambient_description</code></td><td>Configure ambient sound tone and volume (if available)</td></tr>
<tr><td><code>nc_voicedetect_timeout_description</code></td><td>Revert settings when your voice is not detected for a certain amount of time</td></tr>
<tr><td><code>nc_as_header</code></td><td>Ambient sound settings</td></tr>
<tr><td><code>nc_as_custom</code></td><td>Advanced customization</td></tr>
<tr><td><code>nc_as_custom_description</code></td><td>Customize ambient sound settings</td></tr>
<tr><td><code>nc_as_custom_volume_l</code></td><td>Ambient sound volume (left)</td></tr>
<tr><td><code>nc_as_custom_volume_r</code></td><td>Ambient sound volume (right)</td></tr>
<tr><td><code>nc_as_custom_tone</code></td><td>Ambient sound tone</td></tr>
<tr><td><code>nc_as_custom_tone_clear</code></td><td>Clear</td></tr>
<tr><td><code>nc_as_custom_tone_soft</code></td><td>Soft</td></tr>
<tr><td><code>nc_as_custom_tone_neutral</code></td><td>Neutral</td></tr>
<tr><td><code>nc_as_custom_vol_normal</code></td><td>Normal</td></tr>
<tr><td><code>as_header_description</code></td><td>Hear your surroundings</td></tr>
<tr><td><code>as_voicefocus_description</code></td><td>Make voices stand out more</td></tr>
<tr><td><code>adv_pause_playback</code></td><td>Pause playback if earbuds are taken off</td></tr>
<tr><td><code>adv_pause_playback_desc</code></td><td>Sends a global play/pause state change event when both of the proximity sensors are uncovered (Desktop only)</td></tr>
<tr><td><code>adv_callpath</code></td><td>In-ear detection for calls</td></tr>
<tr><td><code>adv_callpath_desc</code></td><td>Play calls through your earbuds when they're in your ears and through your computer speaker when they're not</td></tr>
<tr><td><code>adv_extra_clear_call</code></td><td>Sharpen call sound</td></tr>
<tr><td><code>adv_extra_clear_call_desc</code></td><td>Boost call clarity. Most useful when you're somewhere noisy and using earbuds. Uses more battery.</td></tr>
<tr><td><code>bixby_remap_lang_desc</code></td><td>Change the language used for the activation phrase</td></tr>
<tr><td><code>bixby_remap_action_desc</code></td><td>Define what should happen when you activate Bixby on this device</td></tr>
<tr><td><code>credits_kofi</code></td><td>Visit my Ko-fi page to support me!</td></tr>
<tr><td><code>credits_github</code></td><td>Visit this project on GitHub</td></tr>
<tr><td><code>connlost</code></td><td>Connection lost</td></tr>
<tr><td><code>connlost_troubleshoot</code></td><td>Troubleshoot</td></tr>
<tr><td><code>connlost_troubleshoot_title</code></td><td>How to troubleshoot connection issues</td></tr>
<tr><td><code>connlost_troubleshoot_content</code></td><td>Please make sure that Samsung's official Wearable app for the Galaxy Buds does not attempt to connect to your earbuds in the background.
Otherwise, you will experience very frequent connection loss issues as their app will repeatedly attempt to gain control over the earbuds.

You can choose one of these solutions to fix this issue:

• Unpair the earbuds from the Wearable app. (In the Wearable app, open the hamburger menu, select 'Manage devices', and delete your earbuds from the list.)

• Uninstall the Galaxy Buds plugin for the Samsung Wearable app althogether.

• Use an app like 'Hail' or 'Ice Box' to temporarily freeze the official Galaxy Buds plugin for the Samsung Wearable app to prevent it from running.
    </td></tr>
<tr><td><code>pairingmode_done</code></td><td>The earbuds have been put into pairing mode and are now disconnected from this device.</td></tr>
<tr><td><code>fw_select_install_short</code></td><td>Install</td></tr>
<tr><td><code>fw_select_from_disk_short</code></td><td>Open</td></tr>
<tr><td><code>fw_select_refresh</code></td><td>Refresh</td></tr>
<tr><td><code>fw_select_no_results_short</code></td><td>No updates found</td></tr>
<tr><td><code>fw_select_verify_model_mismatch_fail</code></td><td>Device model mismatch detected! The firmware transfer has been cancelled.

You are attempting to flash a firmware for the {0} onto your {1}. This can permanently brick your earbuds.</td></tr>
<tr><td><code>window_open</code></td><td>Open</td></tr>
<tr><td><code>budsapp_header</code></td><td>Bluetooth compatibility info</td></tr>
<tr><td><code>budsapp_text_p1</code></td><td>The official Galaxy Buds app is installed alongside this application.</td></tr>
<tr><td><code>budsapp_text_p2</code></td><td>If it is active in the background, GalaxyBudsClient might have issues connecting to your earbuds. Make sure to unregister your earbuds from the official app or prevent it from running in the background by other means.</td></tr>
<tr><td><code>budsapp_text_p3</code></td><td>Keep in mind that only one application can talk to your Galaxy Buds at a time.</td></tr>
<tr><td><code>manualpair_title</code></td><td>Manual device selection</td></tr>
<tr><td><code>manualpair_title_dialog</code></td><td>Choose your Galaxy Buds device</td></tr>
<tr><td><code>manualpair_model</code></td><td>Choose the correct model type</td></tr>
<tr><td><code>manualpair_note</code></td><td>You should only manually connect your earbuds if the setup wizard does not recognize them correctly.</td></tr>
<tr><td><code>rename</code></td><td>Rename earbuds</td></tr>
<tr><td><code>rename_desc</code></td><td>This will rename earbuds for all devices.</td></tr>
<tr><td><code>rename_warn</code></td><td>Renaming your earbuds may not be possible using official apps as they restrict it to Samsung smartphones, which means you may need this app to reset the personalized name. The name change may not be detected by devices until you un-pair and re-pair your earbuds.</td></tr>
<tr><td><code>rename_warn_oneui_title</code></td><td>Important information for OneUI users</td></tr>
<tr><td><code>rename_warn_oneui</code></td><td>If your device is running Samsung OneUI, you should use Samsung's official method to rename your earbuds in the system settings. Otherwise, there will be connection issues while setting a new name.</td></tr>
<tr><td><code>rename_too_short</code></td><td>The name you entered is too short (no characters) or too long (maximum limit imposed by earbuds).</td></tr>
<tr><td><code>rename_hint</code></td><td>Enter new name...</td></tr>
<tr><td><code>rename_label</code></td><td>New device name</td></tr>
<tr><td><code>rename_reading_name</code></td><td>Reading current name...</td></tr>
<tr><td><code>rename_ok_title</code></td><td>Earbuds renamed</td></tr>
<tr><td><code>rename_ok</code></td><td>Successfully renamed your earbuds!
The name change may not be detected by devices (including this one) until you un-pair and re-pair your earbuds.</td></tr>
<tr><td><code>page_spatial_audio</code></td><td>360 Audio</td></tr>
<tr><td><code>spatial_audio_desc</code></td><td>Dynamic head tracking and 360 spatial sound</td></tr>
<tr><td><code>spatial_enable</code></td><td>Enable Head Tracking</td></tr>
<tr><td><code>spatial_enable_desc</code></td><td>Activates internal motion sensors to track head orientation</td></tr>
<tr><td><code>spatial_recenter</code></td><td>Recenter Heading</td></tr>
<tr><td><code>spatial_recenter_desc</code></td><td>Resets front orientation to where you are currently looking</td></tr>
<tr><td><code>spatial_demo_play</code></td><td>Play 360 Audio Demo</td></tr>
<tr><td><code>spatial_demo_stop</code></td><td>Stop 360 Audio Demo</td></tr>
<tr><td><code>spatial_demo_desc</code></td><td>Plays an interactive spatial chime that moves in 3D around you as you turn your head</td></tr>
<tr><td><code>spatial_broadcast_osc</code></td><td>Broadcast via OSC (DAWs / Plugins)</td></tr>
<tr><td><code>spatial_broadcast_osc_desc</code></td><td>Sends real-time yaw, pitch, roll and quaternion to localhost:9000</td></tr>
<tr><td><code>spatial_broadcast_opentrack</code></td><td>Broadcast to Games (OpenTrack)</td></tr>
<tr><td><code>spatial_broadcast_opentrack_desc</code></td><td>Sends FreeTrack / OpenTrack UDP packets to localhost:4242 for flight/driving sims</td></tr>
<tr><td><code>spatial_tracking_active</code></td><td>Tracking active</td></tr>
<tr><td><code>spatial_tracking_inactive</code></td><td>Tracking stopped</td></tr>
<tr><td><code>spatial_speaker_angle</code></td><td>Virtual Soundstage Width</td></tr>
<tr><td><code>spatial_speaker_angle_desc</code></td><td>Adjusts the stereo angle of the virtual front speakers</td></tr>
<tr><td><code>spatial_ambience</code></td><td>Room Ambience</td></tr>
<tr><td><code>spatial_ambience_desc</code></td><td>Simulates studio acoustic reflections to externalize sound</td></tr>
<tr><td><code>spatial_system_audio</code></td><td>System-Wide 360 Audio</td></tr>
<tr><td><code>spatial_system_audio_desc</code></td><td>Applies 360 head tracking to all system sound (Spotify, YouTube, movies, games)</td></tr>
<tr><td><code>spatial_blackhole_status_ok</code></td><td>BlackHole 2ch virtual driver ready</td></tr>
<tr><td><code>spatial_blackhole_status_restart_needed</code></td><td>BlackHole installed, please restart CoreAudio to activate</td></tr>
<tr><td><code>spatial_blackhole_status_missing</code></td><td>BlackHole 2ch required on macOS</td></tr>
<tr><td><code>spatial_blackhole_missing_desc</code></td><td>To capture macOS system audio for 360 spatialization, the free open-source BlackHole 2ch driver is required.</td></tr>
<tr><td><code>spatial_blackhole_howto</code></td><td>How to use: Select 'BlackHole 2ch' as your macOS Sound Output, then turn on the switch above to hear everything in 360.</td></tr>
<tr><td><code>spatial_blackhole_install</code></td><td>Install BlackHole (Homebrew)</td></tr>
<tr><td><code>spatial_blackhole_restart</code></td><td>Restart CoreAudio (Activate Driver)</td></tr>
<tr><td><code>spatial_open_audio_midi</code></td><td>Open Audio MIDI Setup</td></tr>
<tr><td><code>spatial_open_sound_pref</code></td><td>Open Sound Settings</td></tr>
<tr><td><code>spatial_windows_info</code></td><td>On Windows, system audio is captured natively via WASAPI Loopback without needing any third-party virtual drivers. Head tracking can also be broadcast to PC games via OpenTrack (port 4242) or VRChat via OSC (port 9000).</td></tr>

</table>

__________

Powered by [ThePBone/XamlTranslationValidator](https://github.com/ThePBone/XamlTranslationValidator)