# Localization status

This file is auto-generated and automatically updated. Do not modify this file manually.

Translation instructions are available [in the wiki](https://github.com/ThePBone/GalaxyBudsClient/wiki/3.-How-to-help-with-translations).

<table>
<tr><th>Language</th><th>Progress</th><th>Missing strings</th><th>Details</th></tr>
<tr><td>ar (Argentina)</td><td>93%</td><td>38 missing string(s)</td><td><a href="ar.md">View details</a></td></tr>
<tr><td>br (Brazil)</td><td>98%</td><td>7 missing string(s)</td><td><a href="br.md">View details</a></td></tr>
<tr><td>cn (China)</td><td>93%</td><td>38 missing string(s)</td><td><a href="cn.md">View details</a></td></tr>
<tr><td>cz (Czechia)</td><td>92%</td><td>42 missing string(s)</td><td><a href="cz.md">View details</a></td></tr>
<tr><td>de (Germany)</td><td>41%</td><td>353 missing string(s)</td><td><a href="de.md">View details</a></td></tr>
<tr><td>es (Spain)</td><td>24%</td><td>453 missing string(s)</td><td><a href="es.md">View details</a></td></tr>
<tr><td>fa (undefined)</td><td>85%</td><td>89 missing string(s)</td><td><a href="fa.md">View details</a></td></tr>
<tr><td>fr (France)</td><td>50%</td><td>294 missing string(s)</td><td><a href="fr.md">View details</a></td></tr>
<tr><td>gr (Greece)</td><td>41%</td><td>352 missing string(s)</td><td><a href="gr.md">View details</a></td></tr>
<tr><td>hu (Hungary)</td><td>56%</td><td>262 missing string(s)</td><td><a href="hu.md">View details</a></td></tr>
<tr><td>il (Israel)</td><td>56%</td><td>262 missing string(s)</td><td><a href="il.md">View details</a></td></tr>
<tr><td>in (India)</td><td>24%</td><td>450 missing string(s)</td><td><a href="in.md">View details</a></td></tr>
<tr><td>it (Italy)</td><td>93%</td><td>38 missing string(s)</td><td><a href="it.md">View details</a></td></tr>
<tr><td>ja (undefined)</td><td>24%</td><td>453 missing string(s)</td><td><a href="ja.md">View details</a></td></tr>
<tr><td>ko (undefined)</td><td>94%</td><td>31 missing string(s)</td><td><a href="ko.md">View details</a></td></tr>
<tr><td>nl (Netherlands)</td><td>57%</td><td>257 missing string(s)</td><td><a href="nl.md">View details</a></td></tr>
<tr><td>pl (Poland)</td><td>92%</td><td>42 missing string(s)</td><td><a href="pl.md">View details</a></td></tr>
<tr><td>pt (Portugal)</td><td>98%</td><td>7 missing string(s)</td><td><a href="pt.md">View details</a></td></tr>
<tr><td>ro (Romania)</td><td>50%</td><td>294 missing string(s)</td><td><a href="ro.md">View details</a></td></tr>
<tr><td>ru (Russian Federation)</td><td>93%</td><td>38 missing string(s)</td><td><a href="ru.md">View details</a></td></tr>
<tr><td>sk (Slovakia)</td><td>93%</td><td>38 missing string(s)</td><td><a href="sk.md">View details</a></td></tr>
<tr><td>sv (El Salvador)</td><td>93%</td><td>38 missing string(s)</td><td><a href="sv.md">View details</a></td></tr>
<tr><td>tr (Turkey)</td><td>93%</td><td>38 missing string(s)</td><td><a href="tr.md">View details</a></td></tr>
<tr><td>tw (Taiwan, Province of China)</td><td>93%</td><td>38 missing string(s)</td><td><a href="tw.md">View details</a></td></tr>
<tr><td>ua (Ukraine)</td><td>50%</td><td>294 missing string(s)</td><td><a href="ua.md">View details</a></td></tr>
<tr><td>vn (Viet Nam)</td><td>93%</td><td>38 missing string(s)</td><td><a href="vn.md">View details</a></td></tr>

</table>

__________

Powered by [ThePBone/XamlTranslationValidator](https://github.com/ThePBone/XamlTranslationValidator)