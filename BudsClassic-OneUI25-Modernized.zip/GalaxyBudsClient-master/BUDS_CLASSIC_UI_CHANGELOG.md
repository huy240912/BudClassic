One UI 2.5 modernized home: header, dark blue hero, section label, spacing, blue accent. Existing bindings and controls retained. Popup unchanged. Build not verified.
