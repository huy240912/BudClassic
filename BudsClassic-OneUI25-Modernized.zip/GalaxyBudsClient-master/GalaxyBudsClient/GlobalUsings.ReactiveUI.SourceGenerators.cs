global using ReactiveUI.SourceGenerators;
