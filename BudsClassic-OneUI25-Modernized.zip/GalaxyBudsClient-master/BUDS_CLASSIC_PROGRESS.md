# Buds Classic: Android 10 prototype

Based on GalaxyBudsClient (GPL-3.0). Keep original copyright notices and source/license when distributing.

## Changes implemented
- Android launcher title renamed to **Buds Classic**.
- Android application ID changed to `org.budsclassic.prototype` to avoid overwriting the original app.
- Added a native Android connection dialog triggered by a Bluetooth ACL connection for devices whose name contains `Buds` **while the app is in the foreground**.
- Existing Buds Core device specification includes `GamingMode`, ANC, EQ protocol capabilities; no new control implementation has been verified.
- Android project supports minimum API 24, including Android 10 API 29.

## Not yet implemented
- Automatic popup while app is closed/backgrounded (requires service, permissions and lifecycle handling).
- One UI 2.5-inspired complete UI redesign and custom artwork/animation.
- Real device tests for battery, ANC, EQ, touch controls and Game Mode.
- Build/test APK: .NET 10 SDK and Android workload are not installed in this environment.

## Build requirements
Install .NET 10 SDK, Android workload (`dotnet workload install android`) and Android SDK. Build Android project with `dotnet publish GalaxyBudsClient.Android/GalaxyBudsClient.Android.csproj -c Release -f net10.0-android36.1 -p:RuntimeIdentifier=android-arm64`. Consult original project build notes for signing/other flags. A successful build does not establish that Bluetooth features work on your Note 9.
